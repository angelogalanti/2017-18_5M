$(document).ready(function() {

var offset = $( "#rocket" ).offset();

$(document).keydown(function(key) {
	switch(parseInt(key.which,10)) { // see URL at bottom
	
		// left arrow pressed
		case 37:
		// up arrow pressed
		case 38:
		// right arrow pressed
		case 39:
		// down arrow pressed
		case 40:
		}
	});

});
